<?php


class Demo_Content_Settings_Object extends Runway_Object {

	public function __construct($settings){

		// No public functions

	}

} 

?>