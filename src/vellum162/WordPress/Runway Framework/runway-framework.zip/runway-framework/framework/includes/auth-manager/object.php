<?php

class Auth_Manager_Object extends Runway_Object{

	function __construct($settings) {
		parent::__construct($settings);
	}
}

?>
