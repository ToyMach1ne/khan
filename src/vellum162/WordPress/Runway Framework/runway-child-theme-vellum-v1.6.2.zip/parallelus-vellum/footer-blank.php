			<?php 
			
			/* LAYOUT MANAGER DISABLED ON BLANK TEMPLATE */

			// Layout Manager - End Layout
			//................................................................
			// do_action('output_layout','end'); 

			?>
		</div><!-- .main-content -->
	</div><!-- #Middle -->
</div><!-- #page -->

<?php wp_footer(); ?>
</body>
</html>